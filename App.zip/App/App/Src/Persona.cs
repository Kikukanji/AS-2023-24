﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace App.Src
{
    public class Persona 
    {
        public int Id { get; set; }
        [Required]
        public string Nome { get; set; }
        [Required]
        public string Cognome { get; set; }
        [Required]
        public string Sesso { get; set; }
        [Required]
        public string LuogoNascita { get; set; }
        [Required]
        public DateTime DataNascita { get; set; }
        [Required]
        public string CF { get; set; }

        public Persona() { }

        public Persona(string nome, string cognome, string sesso, string luogoNascita, DateTime dataNascita, string Cf)
        {
            Nome = nome;
            Cognome = cognome;
            Sesso = sesso;
            LuogoNascita = luogoNascita;
            DataNascita = dataNascita;
            CF = Cf;
        }
    }
}
