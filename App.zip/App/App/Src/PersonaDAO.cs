﻿namespace App.Src
{
    class PersonaDAO
    {
        List<Persona> repository;
        PersonaDAODB PersonaDAODB = new();
        public PersonaDAO()
        {
            PersonaDAODB.ApriConnessione();
            repository = PersonaDAODB.Lettura();
        }

        public void LeggiDB(List<Persona> personas)
        {
            if (personas != null)
                repository = personas;
        }

        public void Inserisci(Persona p)
        {
            if (repository.Count > 0)
                p.Id = repository.Last().Id + 1;
            else p.Id = 1;
            PersonaDAODB.ApriConnessione();
            PersonaDAODB.Inserimento(p);
            repository.Add(p);
        }

        public void Modifica(Persona persona, int id)
        {
            PersonaDAODB.Modifica(persona);
            repository[repository.FindIndex(x => x.Id == id)] = persona;
        }

        public void Rimuovi(int id)
        {
            PersonaDAODB.Rimuovi(id);
            repository.RemoveAt(repository.IndexOf(repository.Find(x => x.Id == id)));
        }

        public List<Persona> GetPersone()
        {
            return repository;
        }
    }
}
