﻿using App.Models;
using App.Src;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace App.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public HomeController(ILogger<HomeController> logger)
        {
            
            _logger = logger;
        }

        public IActionResult Index()
        {
            
            return View();
        }
        public IActionResult Elimina(int id)
        {

            return View();
        }
        public IActionResult AggiungiPersona()
        {
            return View();
        }
        public IActionResult Modifica(Persona persona)
        {

            return View(persona);
        }
        [Route("Delete/{Id}")]
        public IActionResult Cancella(int id)
        {
            DependencyInjectionSetup.Service.GetService<PersonaDAO>().Rimuovi(id);
            DependencyInjectionSetup.Loading();
                return RedirectToAction("Index");

        }
        public IActionResult Aggiungi(Persona? persona)
        {
            if (ModelState.IsValid) {
                DependencyInjectionSetup.Service.GetService<PersonaDAO>().Inserisci(persona);
                DependencyInjectionSetup.Loading();
                return RedirectToAction("Index");
            }
            
            return RedirectToAction("AggiungiPersona");
        }
        public IActionResult Reset()
        {
            DependencyInjectionSetup.Loading();
            return RedirectToAction("Index");
        }
        public IActionResult CercaPersona(TypeSearch? typeSearch)
        {
            if(typeSearch is not null && typeSearch._typeSearch is not null && typeSearch._query is not null)
            DependencyInjectionSetup.SearchPersona(typeSearch._typeSearch.ToLower(), typeSearch._query.ToLower());
            return RedirectToAction("Index" , "Home");
        }
        [Route("Update/{Id}")]
        public IActionResult Modifica(int id)
        {
            var persona = DependencyInjectionSetup.Persone.Find(x => x.Id == id);
            return RedirectToAction("ModificaPersona", "Home", persona);
        }
        public IActionResult ApplicaModifica(Persona? persona)
        {
            DependencyInjectionSetup.Service.GetService<PersonaDAO>().Modifica(persona, persona.Id);
            DependencyInjectionSetup.Loading();
            return RedirectToAction("Index");
        }
        public IActionResult ModificaPersona(Persona persona)
        {

            return View(persona);
        }
        public IActionResult Privacy()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Elenco(TypeSearch search)
        {

            DependencyInjectionSetup.SearchPersona(search._typeSearch, search._query);
            return View();

        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
