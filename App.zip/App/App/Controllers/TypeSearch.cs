﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace App.Controllers
{
    public class TypeSearch
    {


        public TypeSearch() { }
        public TypeSearch(string typeSearch, string query)
        {
            _typeSearch = typeSearch;
            _query = query;
        }
        [Required]
        public string _typeSearch { get; set; } = string.Empty;
        [Required]
        public string _query { get; set; } = string.Empty;
    }
}
