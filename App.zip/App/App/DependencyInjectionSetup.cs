﻿using App.Src;

namespace App
{
    public static class DependencyInjectionSetup
    {
        public static ServiceProvider Service;
        public static List<Persona> Persone;
        public static IServiceCollection RegisterServices(this IServiceCollection services)
        {
            services.AddControllersWithViews();
            services.AddSingleton<PersonaDAODB>();
            services.AddSingleton<PersonaDAO>();
       
            var temp  = services;
            Service = temp.BuildServiceProvider();
            return services;
        }
        public static void Loading()
        {
            Persone = Service.GetService<PersonaDAO>().GetPersone();
        }

        public static void SearchPersona(string type , string query)
        {
            Persone = type switch
            {
                "id" => Service.GetService<PersonaDAO>().GetPersone().Where(x => x.Id.ToString() == query).ToList(),
                "nome" => Service.GetService<PersonaDAO>().GetPersone().Where(x => x.Nome.ToLower().Contains(query)).ToList(),
                "cognome" => Service.GetService<PersonaDAO>().GetPersone().Where(x => x.Cognome.ToLower().Contains(query)).ToList(),
                "cf" => Service.GetService<PersonaDAO>().GetPersone().Where(x => x.CF.ToString().ToLower().Contains(query)).ToList(),
                _ => Service.GetService<PersonaDAO>().GetPersone().ToList()

            };
            
        }
    }
}
