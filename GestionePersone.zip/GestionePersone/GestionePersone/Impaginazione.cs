﻿class Impaginazione
{
    public int LungezzaPagina { get; set; }
    public int PaginaCorrente {  get; set; }

    public Impaginazione()
    {
        LungezzaPagina = 3;
        PaginaCorrente = 1;
    }

}
